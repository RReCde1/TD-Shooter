import pygame
import sys
import random
import math
from screeninfo import get_monitors
for m in get_monitors():
    swidth = m.width
    sheight = m.height


# Initialize Pygame
pygame.init()

# At the beginning of your code
mouse_button_held = False

# Display settings
width, height = swidth, sheight
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Survival Game")

# Player settings
player_pos = [width/2, height/2]
player_speed = 5
player_size = 20
player_health = 100
player_ammo = 50
player_score = 0

kill_score = 2
health_score = 1
ammo_score = 1

# Health bar settings
health_max = 100  # Maximum health value
health_bar_width = 200
health_bar_height = 20
health_bar_border = 2
health_bar_color = (0, 255, 0)
health_bar_bg_color = (255, 0, 0)

GUN_PISTOL = "pistol"
GUN_AR = "rifle"
GUN_SHOTGUN = "shotgun"


WEAPON_PISTOL = GUN_PISTOL
WEAPON_AR = GUN_AR
WEAPON_SHOTGUN = GUN_SHOTGUN

# Gun settings
gun_type = GUN_AR
guns = {
    GUN_PISTOL: {"ammo_per_shot": 1, "bullet_spread": [0], "fire_rate": 20, "bullet_speed": 10, "damage": 3},
    GUN_AR: {"ammo_per_shot": 3, "bullet_spread": [0, 0, 0], "fire_rate": 10, "bullet_speed": 10, "damage": 5},
    GUN_SHOTGUN: {"ammo_per_shot": 3, "bullet_spread": [-0.1, 0, 0.1], "fire_rate": 60, "bullet_speed": 10, "damage": 7}
}

# Weapon-specific attributes
weapons = {
    WEAPON_PISTOL: {"gun_type": GUN_PISTOL, "ammo_per_crate": 20},
    WEAPON_AR: {"gun_type": GUN_AR, "ammo_per_crate": 30},
    WEAPON_SHOTGUN: {"gun_type": GUN_SHOTGUN, "ammo_per_crate": 30}
}



current_gun = guns[gun_type]
gun_cooldown = 0

# Enemy settings
enemies = []
enemyBullets = []
enemy_spawn_rate = 120  # Spawn an enemy every 60 frames
enemy_types = {
    "normal": {"color": (0, 255, 0), "size": 20, "speed": 2, "health": 10, "damage": 5, "score": 5},
    "juggernaut": {"color": (255, 0, 0), "size": 40, "speed": 1, "health": 50, "damage": 10, "score": 10},
    "fast": {"color": (0, 0, 255), "size": 15, "speed": 4, "health": 5, "damage": 5, "score": 1},
    "archer": {"color": (128, 0, 128), "size": 25, "speed":0, "health": 15, "damage": 8, "score": 1},
}
boss_types = {
    "boss": {"color": (255, 0, 255), "size": 80, "speed": 1, "health": 400, "damage": 100, "score": 50, "wave": 5 },
    "bossE": {"color": (0, 255, 255), "size": 80, "speed": 1, "health": 400, "damage": 100, "score": 50, "wave": 10 },
    "bossA": {"color": (255, 255, 255), "size": 80, "speed": 1, "health": 400, "damage": 100, "score": 50, "wave": 2 }
}

wall_width = 100
wall_height = 20
wall_speed = 2
walls = []
wall_spawn_rate = 300


def spawn_wall():
    x = random.randint(0, width - wall_width)
    walls.append({"x": x, "y": -wall_height})

# Weapon crate settings
weapon_crates = []
weapon_crate_size = 20
weapon_spawn_rate = 500  # Spawn a weapon crate every 500 frames

# Bullet settings
bullets = []
bullet_radius = 5

# Ammo crate settings
ammo_crates = []
ammo_crate_size = 20
ammo_crate_bullets = 20
ammo_spawn_rate = 300  # Spawn an ammo crate every 300 frames

bossLasers = []

# Health pack settings
health_packs = []
health_pack_size = 20
health_spawn_rate = 400  # Spawn a health pack every 400 frames
health_value = 10  # Amount of health gained from a health pack

highscore_file = "highscore.txt"

boss_interval = 5

def calculate_enemies_in_wave(wave_number):
    base_enemies = 5  # Number of enemies in the first wave
    enemies_per_wave = 3  # Additional enemies added per wave  # Spawn a boss every 5 waves
    boss_spawn = (wave_number % boss_interval == 0)  # Check if it's time to spawn a boss
    return base_enemies + (wave_number - 1) * enemies_per_wave + boss_spawn

current_wave = 1
enemies_spawned_in_current_wave = 0
enemies_in_current_wave = calculate_enemies_in_wave(current_wave)
enemies_remaining = enemies_in_current_wave
total_waves = 20  # Adjust the total number of waves
kills = 0
# Load highscore
def load_highscore():
    try:
        with open(highscore_file, "r") as file:
            return int(file.read())
    except FileNotFoundError:
        return 0

def draw_text(text, font, color, x, y):
    text_surface = font.render(text, True, color)
    text_rect = text_surface.get_rect()
    text_rect.topleft = (x, y)
    screen.blit(text_surface, text_rect)

# Save highscore
def save_highscore(score):
    with open(highscore_file, "w") as file:
        file.write(str(score))

# Initialize highscore
highscore = load_highscore()

# Game loop
frame_count = 0
clock = pygame.time.Clock()
game_over = False
a = True

def shoot(enemy):
    num_lasers = 15  # Number of lasers
    angle_increment = 2 * math.pi / num_lasers
    angle = 0
    for _ in range(num_lasers):
        bullet = {
            "pos": enemy["pos"].copy(),
            "angle": angle,
            "damage": 15  # Adjust damage as needed
        }
        enemyBullets.append(bullet)
        angle += angle_increment

while not game_over:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.MOUSEBUTTONDOWN and not game_over:
            mouse_button_held = True  # Mouse button is held down

        if event.type == pygame.MOUSEBUTTONUP:
            mouse_button_held = False  # Mouse button is released
    
    # Shooting logic for automatic weapon
    if mouse_button_held and gun_cooldown <= 0 and player_ammo >= current_gun["ammo_per_shot"]:
        mouse_x, mouse_y = pygame.mouse.get_pos()
        for angle_offset in current_gun["bullet_spread"]:
            bullet = {
                "pos": player_pos.copy(),
                "angle": math.atan2(mouse_y - player_pos[1], mouse_x - player_pos[0]) + angle_offset,
                "damage": current_gun["damage"]
            }
            bullets.append(bullet)
            player_ammo -= current_gun["ammo_per_shot"]
        gun_cooldown = current_gun["fire_rate"]

    # Make sure player ammo doesn't go below 0
    player_ammo = max(player_ammo, 0)


    if enemies_spawned_in_current_wave == enemies_in_current_wave and not enemies:
        current_wave += 1
        player_score += 5
        enemies_spawned_in_current_wave = 0
        enemies_in_current_wave = calculate_enemies_in_wave(current_wave)  # Define this function to adjust enemies per wave
        for key in boss_types.keys():
            if current_wave == boss_types[key]['wave']:
                    # Spawn a boss
                    boss_info = boss_types[key]
                    enemy = {
                        "pos": [random.randint(0, width - boss_info["size"]), random.randint(0, height - boss_info["size"])],
                        "type": key,
                        "color": boss_info["color"],
                        "size": boss_info["size"],
                        "speed": boss_info["speed"],
                        "health": boss_info["health"],
                        "damage": boss_info["damage"],
                        "score": boss_info["score"]
                    }
                    enemies.append(enemy)
                    continue

    if enemies_remaining > 0 and current_wave <= total_waves:
        enemies_to_spawn = min(enemies_remaining, 20)
        
        if frame_count % enemy_spawn_rate == 0 and enemies_spawned_in_current_wave < enemies_in_current_wave:
            enemy_type = random.choice(list(enemy_types.keys()))
            enemy_info = enemy_types[enemy_type]
            enemy = {
                "pos": [random.randint(0, width - enemy_info["size"]), random.randint(0, height - enemy_info["size"])],
                "type": enemy_type,
                "color": enemy_info["color"],
                "size": enemy_info["size"],
                "speed": enemy_info["speed"],
                "health": enemy_info["health"],
                "damage": enemy_info["damage"],
                "score": enemy_info["score"]
            }
            enemies.append(enemy)
            enemies_spawned_in_current_wave += 1


    if enemies_spawned_in_current_wave == enemies_in_current_wave and not enemies:
        current_wave += 1
        enemies_spawned_in_current_wave = 0
        enemies_in_current_wave = calculate_enemies_in_wave(current_wave)


    keys = pygame.key.get_pressed()
    if keys[pygame.K_w]:
        player_pos[1] -= player_speed
    if keys[pygame.K_ESCAPE]:
        pygame.quit()
        sys.exit()
    if keys[pygame.K_s]:
        player_pos[1] += player_speed
    if keys[pygame.K_a]:
        player_pos[0] -= player_speed
    if keys[pygame.K_d]:
        player_pos[0] += player_speed

    frame_count += 1
    
    for wall in walls.copy():
        wall["y"] += wall_speed

        if wall["y"] > height:
            walls.remove(wall)
        else:
            pygame.draw.rect(screen, (128, 128, 128), (wall["x"], wall["y"], wall_width, wall_height))

    

    # Update enemy positions and prevent overlap
    for enemy in enemies:
        if not game_over:
            direction = math.atan2(player_pos[1] - enemy["pos"][1], player_pos[0] - enemy["pos"][0])
            enemy["pos"][0] += math.cos(direction) * enemy["speed"]
            enemy["pos"][1] += math.sin(direction) * enemy["speed"]

        # Check for collisions with other enemies
        for other_enemy in enemies:
            if other_enemy != enemy:
                dx = other_enemy["pos"][0] - enemy["pos"][0]
                dy = other_enemy["pos"][1] - enemy["pos"][1]
                distance = math.sqrt(dx**2 + dy**2)

                if distance < enemy["size"] * 2:  # Adjust the value for desired spacing
                    # Move the enemy away from the other_enemy
                    overlap = enemy["size"] * 2 - distance
                    angle = math.atan2(dy, dx)
                    enemy["pos"][0] -= overlap * math.cos(angle)
                    enemy["pos"][1] -= overlap * math.sin(angle)
                    
        
        if not game_over:
            direction = math.atan2(player_pos[1] - enemy["pos"][1], player_pos[0] - enemy["pos"][0])
            enemy["pos"][0] += math.cos(direction) * enemy["speed"]
            enemy["pos"][1] += math.sin(direction) * enemy["speed"]
            
            if (player_pos[0] < enemy["pos"][0] + enemy_info["size"] and
            player_pos[0] + player_size > enemy["pos"][0] and
            player_pos[1] < enemy["pos"][1] + enemy_info["size"] and
            player_pos[1] + player_size > enemy["pos"][1]):
                if not game_over:
                    player_health -= enemy["damage"]
                    if player_health <= 0:
                        game_over = True
                        print("Game Over!")
                    enemies.remove(enemy)


        if enemy["type"] == "archer":
            if frame_count % 100 == 0:  # Adjust the shooting rate as needed
                bullet = {
                    "pos": enemy["pos"].copy(),
                    "angle": math.atan2(player_pos[1] - enemy["pos"][1], player_pos[0] - enemy["pos"][0])
                }
                enemyBullets.append(bullet)
        
        if enemy["type"] == "boss" and frame_count % 150 == 0:
            # Shoot a laser every 150 frames
            laser = {
                "pos": enemy["pos"].copy(),
                "angle": math.atan2(player_pos[1] - enemy["pos"][1], player_pos[0] - enemy["pos"][0])
            }
            bossLasers.append(laser)
        
        if enemy["type"] == "bossE":
            if frame_count % 150 == 0:  # Adjust shooting rate
                shoot(enemy)

        if enemy["type"] == "bossA":
            if frame_count % wall_spawn_rate == 0 and not game_over:
                spawn_wall()
                shoot(enemy)
                laser = {
                    "pos": enemy["pos"].copy(),
                    "angle": math.atan2(player_pos[1] - enemy["pos"][1], player_pos[0] - enemy["pos"][0])
                }
                bossLasers.append(laser)
            
        for wall in walls.copy():
            wall["y"] += wall_speed

            if wall["y"] > height:
                walls.remove(wall)
            else:
                pygame.draw.rect(screen, (128, 128, 128), (wall["x"], wall["y"], wall_width, wall_height))      

    # Update ammo crate spawning
    if frame_count % ammo_spawn_rate == 0 and not game_over:
        ammo_crate = {
            "pos": [random.randint(0, width - ammo_crate_size), random.randint(0, height - ammo_crate_size)]
        }
        ammo_crates.append(ammo_crate)

    # Update health pack spawning
    if frame_count % health_spawn_rate == 0 and not game_over:
        health_pack = {
            "pos": [random.randint(0, width - health_pack_size), random.randint(0, height - health_pack_size)]
        }
        health_packs.append(health_pack)

    
    if current_wave > total_waves:
        game_over = True
        print('You beat the game!')
        break
    
    if player_health <= 0:
        game_over = True
        print("Game Over!")

    # Update bullet positions
    for bullet in bullets:
        bullet["pos"][0] += math.cos(bullet["angle"]) * current_gun["bullet_speed"]
        bullet["pos"][1] += math.sin(bullet["angle"]) * current_gun["bullet_speed"]
    
    for bullet in enemyBullets:
        bullet["pos"][0] += math.cos(bullet["angle"]) * 10
        bullet["pos"][1] += math.sin(bullet["angle"]) * 10

    for laser in bossLasers.copy():
        laser["pos"][0] += math.cos(laser["angle"]) * 8  # Adjust laser speed as needed
        laser["pos"][1] += math.sin(laser["angle"]) * 8
        # Check collision between boss lasers and the player
        if (player_pos[0] < laser["pos"][0] + bullet_radius and
                player_pos[0] + player_size > laser["pos"][0] and
                player_pos[1] < laser["pos"][1] + bullet_radius and
                player_pos[1] + player_size > laser["pos"][1]):
            bossLasers.remove(laser)
            player_health -= 15  # Decrease player's health
            if player_health <= 0:
                game_over = True
                print("Game Over!")

    # Update weapon crate spawning
    if frame_count % weapon_spawn_rate == 0 and not game_over:
        weapon_crate = {
            "pos": [random.randint(0, width - weapon_crate_size), random.randint(0, height - weapon_crate_size)],
            "weapon_type": random.choice([WEAPON_AR, WEAPON_PISTOL, WEAPON_SHOTGUN])
        }
        weapon_crates.append(weapon_crate)

    # Check collision between player and weapon crates
    for weapon_crate in weapon_crates.copy():  # Create a copy to iterate over
        if (player_pos[0] < weapon_crate["pos"][0] + weapon_crate_size and
                player_pos[0] + player_size > weapon_crate["pos"][0] and
                player_pos[1] < weapon_crate["pos"][1] + weapon_crate_size and
                player_pos[1] + player_size > weapon_crate["pos"][1]):
            weapon_crates.remove(weapon_crate)
            player_ammo += weapons[weapon_crate["weapon_type"]]["ammo_per_crate"]
            gun_type = weapons[weapon_crate["weapon_type"]]["gun_type"]
            current_gun = guns[gun_type]


    # Check collision between bullets and enemies
    for bullet in bullets:
        for enemy in enemies:
            if (enemy["pos"][0] < bullet["pos"][0] + bullet_radius and
                    enemy["pos"][0] +  enemy["size"] > bullet["pos"][0] and
                    enemy["pos"][1] < bullet["pos"][1] + bullet_radius and
                    enemy["pos"][1] + enemy["size"] > bullet["pos"][1]):
                bullets.remove(bullet)
                enemy["health"] -= bullet["damage"]
                if enemy["health"] <= 0:
                    enemies.remove(enemy)
                    kills += 1
                player_ammo += 5  # Gain ammo after killing an enemy
                player_score += enemy["score"]
                

    for bullet in enemyBullets.copy():
        if (player_pos[0] < bullet["pos"][0] + bullet_radius and
                player_pos[0] + player_size > bullet["pos"][0] and
                player_pos[1] < bullet["pos"][1] + bullet_radius and
                player_pos[1] + player_size > bullet["pos"][1]):
            enemyBullets.remove(bullet)
            player_health -= 8  # Decrease player's health
            if player_health <= 0:
                game_over = True
                print("Game Over!")

    # Check collision between player and ammo crates
    for ammo_crate in ammo_crates:
        if (player_pos[0] < ammo_crate["pos"][0] + ammo_crate_size and
                player_pos[0] + player_size > ammo_crate["pos"][0] and
                player_pos[1] < ammo_crate["pos"][1] + ammo_crate_size and
                player_pos[1] + player_size > ammo_crate["pos"][1]):
            ammo_crates.remove(ammo_crate)
            player_ammo += ammo_crate_bullets  # Gain ammo from ammo crate
            player_score += ammo_score

    # Check collision between player and health packs
    for health_pack in health_packs:
        if (player_pos[0] < health_pack["pos"][0] + health_pack_size and
                player_pos[0] + player_size > health_pack["pos"][0] and
                player_pos[1] < health_pack["pos"][1] + health_pack_size and
                player_pos[1] + player_size > health_pack["pos"][1]):
            health_packs.remove(health_pack)
            player_health = min(player_health + health_value, 100)  # Regain health from health pack
            player_score += health_score

    # Clear the screen
    screen.fill((0, 100, 0))

    # Draw bullets
    for bullet in bullets:
        pygame.draw.circle(screen, (0, 0, 255), (int(bullet["pos"][0]), int(bullet["pos"][1])), bullet_radius)

    # Draw enemy bullets
    for bullet in enemyBullets:
        pygame.draw.circle(screen, (0, 0, 255), (int(bullet["pos"][0]), int(bullet["pos"][1])), bullet_radius)

    # Draw boss lasers
    for laser in bossLasers:
        pygame.draw.line(screen, (255, 0, 0), laser["pos"], (laser["pos"][0] + 100 * math.cos(laser["angle"]), laser["pos"][1] + 100 * math.sin(laser["angle"])), 3)

    if not enemies and current_wave > total_waves:
        # Reset boss lasers when no enemies are left and all waves are completed
        bossLasers.clear()

    # Draw enemies
    for enemy in enemies:
        pygame.draw.rect(screen, enemy["color"], (enemy["pos"][0], enemy["pos"][1], enemy["size"], enemy["size"]))
        # Calculate the width of the health bar based on the enemy's health
        if enemy['type'] == "boss" or enemy['type'] == "bossE"  or enemy['type'] == "bossA":
                health_bar_width1 = enemy["health"] / boss_types[enemy["type"]]["health"] * enemy["size"]
                health_bar_height1 = 5
                health_bar_position1 = (enemy["pos"][0], enemy["pos"][1] - health_bar_height1 - 5)
                
        else:
                health_bar_width1 = enemy["health"] / enemy_types[enemy["type"]]["health"] * enemy["size"]
                health_bar_height1 = 5
                health_bar_position1 = (enemy["pos"][0], enemy["pos"][1] - health_bar_height1 - 5)
                
        
        # Draw the health bar background
        pygame.draw.rect(screen, (255, 0, 0), (health_bar_position1[0], health_bar_position1[1], enemy["size"], health_bar_height1))
        
        # Draw the current health level of the enemy
        pygame.draw.rect(screen, (0, 255, 0), (health_bar_position1[0], health_bar_position1[1], health_bar_width1, health_bar_height1))
        
    # Draw ammo crates
    for ammo_crate in ammo_crates:
        pygame.draw.rect(screen, (255, 255, 0), (ammo_crate["pos"][0], ammo_crate["pos"][1], ammo_crate_size, ammo_crate_size))

    # Draw health packs
    for health_pack in health_packs:
        pygame.draw.rect(screen, (0, 255, 255), (health_pack["pos"][0], health_pack["pos"][1], health_pack_size, health_pack_size))

    # Draw weapon crates
    for weapon_crate in weapon_crates:
        pygame.draw.rect(screen, (255, 0, 255), (weapon_crate["pos"][0], weapon_crate["pos"][1], weapon_crate_size, weapon_crate_size))

    # Draw the player
    pygame.draw.rect(screen, (255, 0, 0), (player_pos[0], player_pos[1], player_size, player_size))
    
    # Update highscore if necessary
    if player_score > highscore:
        highscore = player_score
        save_highscore(highscore)


    

    # Display player's health, ammo, and ammo crates count
    font = pygame.font.Font(None, 36)
    # Draw the health bar
    health_bar_rect = pygame.Rect(10, height - 30, health_bar_width, health_bar_height)
    health_bar_fill_rect = pygame.Rect(10 + health_bar_border, height - 30 + health_bar_border,
                                    (health_bar_width - 2 * health_bar_border) * (player_health / health_max), health_bar_height - 2 * health_bar_border)

    pygame.draw.rect(screen, health_bar_bg_color, health_bar_rect)
    pygame.draw.rect(screen, health_bar_color, health_bar_fill_rect)

    score = font.render("Score: " + str(player_score), True, (255, 255, 255))
    hscore = font.render("Highscore: " + str(highscore), True, (255, 255, 255))
    wave = font.render("Wave: " + str(current_wave) + "/" + str(total_waves), True, (255, 255, 255))
    enemiesRe = font.render("Enemies Killed: " + str(kills),  True, (255, 255, 255))
    health_percentage_text = font.render(f"Health: {player_health}%", True, (255, 255, 255))
    draw_text(f"Ammo: {player_ammo}", font, (255, 255, 255), width - 170, height - 100)
    draw_text(f"Gun: {gun_type.capitalize()}", font, (255, 255, 255), width - 170, height - 60)

    screen.blit(score, (10, 40))
    screen.blit(hscore, (10, 70))
    screen.blit(wave, (10, 100))
    screen.blit(enemiesRe, (10, 130))
    screen.blit(health_percentage_text, (10 + health_bar_width + 10, height - 30))
    
    if gun_cooldown > 0:
        gun_cooldown -= 1

    pygame.display.flip()
    clock.tick(60)  # Limit frame rate to 60 FPS

pygame.quit()
sys.exit()